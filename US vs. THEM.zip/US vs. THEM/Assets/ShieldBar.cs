﻿using UnityEngine;
using System.Collections;

public class ShieldBar : MonoBehaviour {

	public EnergyShield Shield;
	public float max_health = 100f;
	public float cur_health = 10f;
	public float calc_health = 1f;
	public GameObject shieldBar;
	
	// Use this for initialization
	void Start () {
		max_health = Shield.Max_Shield_Energy;
		cur_health = max_health;
	}
	
	// Update is called once per frame
	void Update () {
		cur_health = Shield.Shield_Energy;
		calc_health = cur_health / max_health;
		SetHealthBar (calc_health);
	}
	
	public void SetHealthBar(float myHealth)
	{
		shieldBar.transform.localScale = new Vector3 (Mathf.Clamp(myHealth,0f ,1f), shieldBar.transform.localScale.y, shieldBar.transform.localScale.z);
	}
}
