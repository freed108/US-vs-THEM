﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//This code controls how supply generating structures generate supplies

public class SupplyGeneration : MonoBehaviour {

	public Supplies supplies; //This line is necessary to link this program with the code that stores the supply total
	public float Income;
	public float SupplyTimer;
	public float Next;

	// Use this for initialization
	void Start () {
		Next = SupplyTimer;
	}
	
	// Update is called once per frame
	void Update () {
		Next = Next - Time.deltaTime;

		if (Next <= 0) {
			Next = SupplyTimer;
			supplies.Total = supplies.Total + Income;
		}
	}
}
