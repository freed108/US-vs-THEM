﻿using UnityEngine;
using System.Collections;
/*This is the code that controls switching between shooter mode and strategy mode
The button assigned to switching between modes is the 'Q' button*/

public class Mode_Switch : MonoBehaviour {

	public GameObject Hero;
	public GameObject Third_Person_Camera;
	public GameObject Strategy_Camera;
	public GameObject Camera_Reset;
	public CharacterMotor Controller;
	public GameObject Strategy_Mode;
	public GameObject Build_Mode;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Q)) {
			if(Third_Person_Camera.activeSelf == true)
			{
				Third_Person_Camera.SetActive(false);
				Controller.SetControllable(false);
				Strategy_Camera.SetActive(true);
				Strategy_Mode.SetActive(true);
			}

			else
			{
				Third_Person_Camera.SetActive(true);
				Controller.SetControllable(true);
				Strategy_Camera.transform.position = new Vector3 (Camera_Reset.transform.position.x, Camera_Reset.transform.position.y, Camera_Reset.transform.position.z);
				Strategy_Camera.SetActive(false);
				Strategy_Mode.SetActive(false);
			}
		}

		if (Hero == null) {
			Strategy_Camera.SetActive(true);
			Strategy_Mode.SetActive(true);
		}

		if (Input.GetKeyDown (KeyCode.B)) {
			if (Build_Mode.activeSelf == false) {
				Build_Mode.SetActive (true);
			} else {
				Build_Mode.SetActive (false);
			}
		}
	}
}
