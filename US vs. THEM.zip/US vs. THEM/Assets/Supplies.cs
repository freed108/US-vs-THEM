﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//This code stores the number of supplies the player has to build units and buildings with in the strategy mode

public class Supplies : MonoBehaviour {

	public float Initial;
	public float Total;

	// Use this for initialization
	void Start () {
		Total = Initial;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
