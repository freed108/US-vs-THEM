﻿using UnityEngine;
using System.Collections;

public class AI_Movement_Infantry : Pathfinding {

	//public Mouse_Point mouse;
	public Transform player;
	//public GameObject Selected;
	public float playerDistance;
	public float rotationDamping;
	public float moveSpeed;
	public float Don_t_Look;
	Vector3 endPosition;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		playerDistance = Vector3.Distance (player.position, transform.position);
		endPosition = player.position;

		FindPath(transform.position, endPosition);

		if (Path.Count > 0) 
		{
			Move ();
		}
		
		if (playerDistance > Don_t_Look) 
		{
			lookAtPlayer();
		}
		
		/*if (playerDistance > 0.1f) 
		{
			chase ();
		}*/

		/*if(Selected.activeInHierarchy == true)
		{
			player.transform.Translate(mouse.RightClickMarker, mouse.RightClickMarker, mouse.RightClickMarker);
		}*/
	}
	
	void lookAtPlayer()
	{
		Quaternion rotation = Quaternion.LookRotation (player.position - transform.position);
		transform.rotation = Quaternion.Slerp (transform.rotation, rotation, Time.deltaTime * rotationDamping);
	}
	
	/*void chase()
	{
		transform.Translate (Vector3.forward * moveSpeed * Time.deltaTime);
	}*/
}
