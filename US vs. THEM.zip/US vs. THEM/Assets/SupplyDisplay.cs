﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//This code displays the number of supplies the player currently has on the screen

public class SupplyDisplay : MonoBehaviour {

	public Supplies supplies; //This line is necessary to link this program with the code that stores the supply total
	public Text ScreenDisplay;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		ScreenDisplay.text = ("Supplies: " + supplies.Total);
	}
}
