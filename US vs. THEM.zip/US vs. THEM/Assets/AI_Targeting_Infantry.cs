﻿using UnityEngine;
using System.Collections;
using System;
//This code controls the targeting system used by the player's infantry forces

public class AI_Targeting_Infantry : MonoBehaviour {

	public Mouse_Point mouse;
	public float checkRadius = 78.28f;
	public LayerMask checkLayers;
	public Transform player;
	public GameObject target;
	public GameObject selected;
	public GameObject Standard;
	public float playerDistance;
	public float rotationDamping;
	public float Timer = 1.0f;
	public float Refresh = 1.0f;
	public float ChangeTarget = 1.0f;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (mouse.Target != null && selected.activeSelf == true) {
			player = mouse.Target.transform;
		} else if (player == null) {
			player = Standard.transform;
			target.SetActive (false);
		}

		if (Timer <= 0) {
			Collider[] colliders = Physics.OverlapSphere (transform.position, checkRadius, checkLayers);
			Array.Sort (colliders, new DistanceComparer (transform));

			foreach (Collider item in colliders) {
				if (target.activeSelf == false) {
					if (item.transform.Find ("Blue Army")) {
						player = item.transform;
						target.SetActive(true);
					}
				}

				if (item.transform == player) {
					ChangeTarget = 0;
				}
			}

			if (ChangeTarget == 1) {
				player = null;
				target.SetActive(false);
			}

			Timer = Refresh;
			ChangeTarget = 1;
		}

		Timer -= Time.deltaTime;

		playerDistance = Vector3.Distance (player.position, transform.position);
		
		lookAtPlayer();
		
		/*if (playerDistance > 5f && playerDistance < 20f) 
		{
			chase ();
		}*/
		
		/*if(Selected.activeInHierarchy == true)
		{
			player.transform.Translate(mouse.RightClickMarker, mouse.RightClickMarker, mouse.RightClickMarker);
		}*/
	}
	
	void lookAtPlayer()
	{
		Quaternion rotation = Quaternion.LookRotation (player.position - transform.position);
		transform.rotation = Quaternion.Slerp (transform.rotation, rotation, Time.deltaTime * rotationDamping);
	}
	
	/*void chase()
	{
		transform.Translate (Vector3.forward * moveSpeed * Time.deltaTime);
	}*/
}
